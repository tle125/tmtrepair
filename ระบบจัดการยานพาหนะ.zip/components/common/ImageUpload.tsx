
import React, { useState, useRef } from 'react';

interface ImageUploadProps {
  onFilesChange: (files: (File | null)[]) => void;
  maxFiles: number;
}

const ImageUpload: React.FC<ImageUploadProps> = ({ onFilesChange, maxFiles }) => {
  const [previews, setPreviews] = useState<(string | null)[]>(Array(maxFiles).fill(null));
  const [files, setFiles] = useState<(File | null)[]>(Array(maxFiles).fill(null));
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = [...files];
      const newPreviews = [...previews];
      
      Array.from(e.target.files).forEach(file => {
        const emptyIndex = newFiles.findIndex(f => f === null);
        if (emptyIndex !== -1) {
          newFiles[emptyIndex] = file;
          newPreviews[emptyIndex] = URL.createObjectURL(file);
        }
      });

      setFiles(newFiles);
      setPreviews(newPreviews);
      onFilesChange(newFiles);
    }
  };

  const removeImage = (index: number) => {
    const newFiles = [...files];
    const newPreviews = [...previews];
    
    if (newPreviews[index]) {
      URL.revokeObjectURL(newPreviews[index] as string);
    }
    
    newFiles[index] = null;
    newPreviews[index] = null;

    setFiles(newFiles);
    setPreviews(newPreviews);
    onFilesChange(newFiles);
  };
  
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        อัปโหลดรูปภาพ (สูงสุด {maxFiles} รูป)
      </label>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {previews.map((preview, index) => (
          <div key={index} className="relative w-full h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
            {preview ? (
              <>
                <img src={preview} alt={`Preview ${index + 1}`} className="h-full w-full object-cover rounded-lg" />
                <button
                  type="button"
                  onClick={() => removeImage(index)}
                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs"
                >
                  &times;
                </button>
              </>
            ) : (
               <button type="button" onClick={triggerFileInput} className="text-gray-400 hover:text-gray-600">
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 mx-auto">
                   <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
                 </svg>
                 <span className="text-sm mt-1">เพิ่มรูป</span>
               </button>
            )}
          </div>
        ))}
      </div>
       <input
          type="file"
          ref={fileInputRef}
          multiple
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
    </div>
  );
};

export default ImageUpload;
