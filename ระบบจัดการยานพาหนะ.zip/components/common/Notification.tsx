
import React from 'react';

interface NotificationProps {
  message: string;
  isError: boolean;
  onClose: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, isError, onClose }) => {
  const bgColor = isError ? 'bg-red-500' : 'bg-green-500';

  return (
    <div className="fixed top-5 right-5 z-50">
      <div className={`${bgColor} text-white font-bold rounded-lg shadow-lg py-3 px-5 flex items-center`}>
        <span className="flex-grow">{message}</span>
        <button onClick={onClose} className="ml-4 text-white hover:text-gray-200">
          &times;
        </button>
      </div>
    </div>
  );
};

export default Notification;
