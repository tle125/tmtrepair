
import React from 'react';
import { Vehicle } from '../types';
import Spinner from './common/Spinner';

interface VehicleInfoListProps {
  vehicles: Vehicle[];
  isLoading: boolean;
}

const VehicleInfoList: React.FC<VehicleInfoListProps> = ({ vehicles, isLoading }) => {
  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">ข้อมูลรถทั้งหมด</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">เบอร์รถ</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ประเภทรถ</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ประเภทยาง</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ยี่ห้อยาง</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">รายการยาง</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {vehicles.map((vehicle) => (
              <tr key={vehicle.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{vehicle.vehicleNo}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{vehicle.vehicleType}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{vehicle.tireType}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{vehicle.tireBrand}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{vehicle.tireSpec}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
       {vehicles.length === 0 && <p className="text-center text-gray-500 mt-4">ไม่พบข้อมูลรถ</p>}
    </div>
  );
};

export default VehicleInfoList;
