
import React, { useState, useEffect } from 'react';
import { RepairRequest, RepairStatus, Communication } from '../types';
import { getData, updateRepairRequest } from '../services/googleSheetService';
import { SHEET_IDS } from '../constants';
import Spinner from './common/Spinner';

interface RepairRequestListProps {
  onNotification: (notification: { show: boolean; message: string; isError: boolean }) => void;
}

const statusColors: { [key in RepairStatus]: string } = {
  [RepairStatus.Pending]: 'bg-yellow-100 text-yellow-800',
  [RepairStatus.InProgress]: 'bg-blue-100 text-blue-800',
  [RepairStatus.Repaired]: 'bg-green-100 text-green-800',
  [RepairStatus.Closed]: 'bg-gray-100 text-gray-800',
  [RepairStatus.Cancelled]: 'bg-red-100 text-red-800',
  [RepairStatus.InfoRequested]: 'bg-purple-100 text-purple-800',
};

const ManagerActions: React.FC<{ request: RepairRequest; onUpdate: (id: string, updates: Partial<RepairRequest>) => void }> = ({ request, onUpdate }) => {
    const [newStatus, setNewStatus] = useState<RepairStatus>(request.status);

    const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const status = e.target.value as RepairStatus;
        setNewStatus(status);
        onUpdate(request.id, { status });
    };

    return (
        <div className="mt-4 pt-4 border-t">
            <h4 className="text-sm font-semibold text-gray-600 mb-2">สำหรับผู้จัดการ</h4>
            <select
                value={newStatus}
                onChange={handleStatusChange}
                className="w-full p-2 border border-gray-300 rounded-md"
            >
                {Object.values(RepairStatus).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
        </div>
    );
};


const RepairRequestList: React.FC<RepairRequestListProps> = ({ onNotification }) => {
  const [requests, setRequests] = useState<RepairRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchRepairs = async () => {
    setIsLoading(true);
    try {
      const data = await getData<RepairRequest>(SHEET_IDS.repairs);
      setRequests(data.sort((a,b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime() ));
    } catch (error) {
      onNotification({ show: true, message: 'ไม่สามารถโหลดข้อมูลการซ่อมได้', isError: true });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRepairs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleUpdate = async (id: string, updates: Partial<RepairRequest>) => {
      try {
          await updateRepairRequest(id, updates);
          onNotification({ show: true, message: 'อัปเดตสถานะสำเร็จ', isError: false });
          fetchRepairs(); // Refresh data
      } catch (error) {
          onNotification({ show: true, message: 'อัปเดตสถานะไม่สำเร็จ', isError: true });
      }
  };

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">รายการแจ้งซ่อมทั้งหมด</h2>
        <button onClick={fetchRepairs} className="p-2 rounded-full hover:bg-gray-200">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-gray-600">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 11.667 0l3.181-3.183m-4.991-2.696v4.992h-4.992M21.015 4.356v4.992m0 0h-4.992m4.992 0-3.181-3.183a8.25 8.25 0 0 0-11.667 0L2.985 9.348m4.991 2.696H7.98v-4.992h4.992" />
            </svg>
        </button>
      </div>
      {requests.length === 0 ? (
        <p className="text-center text-gray-500 py-8">ไม่มีรายการแจ้งซ่อม</p>
      ) : (
        requests.map(req => (
          <div key={req.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 cursor-pointer hover:bg-gray-50" onClick={() => setExpandedId(expandedId === req.id ? null : req.id)}>
              <div className="flex justify-between items-start">
                  <div>
                      <p className="text-lg font-semibold text-blue-700">{req.vehicleReg}</p>
                      <p className="text-sm text-gray-600">ผู้แจ้ง: {req.requester}</p>
                  </div>
                  <div className="text-right">
                     <span className={`px-3 py-1 text-xs font-semibold rounded-full ${statusColors[req.status]}`}>{req.status}</span>
                     <p className="text-xs text-gray-500 mt-1">วันที่: {new Date(req.requestDate).toLocaleDateString('th-TH')}</p>
                  </div>
              </div>
            </div>
            {expandedId === req.id && (
              <div className="p-4 border-t border-gray-200">
                <p className="text-sm text-gray-800 mb-4"><span className="font-semibold">รายละเอียด:</span> {req.problemDetails}</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
                  {[req.imageUrl1, req.imageUrl2, req.imageUrl3, req.imageUrl4].map((url, i) => 
                      url ? <a key={i} href={url} target="_blank" rel="noopener noreferrer"><img src={url} alt={`รูป ${i+1}`} className="w-full h-24 object-cover rounded-md shadow-sm" /></a> : null
                  )}
                </div>
                {/* Manager actions can be conditionally rendered based on user role */}
                <ManagerActions request={req} onUpdate={handleUpdate} />
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default RepairRequestList;
