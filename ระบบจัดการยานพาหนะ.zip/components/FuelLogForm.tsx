
import React, { useState } from 'react';
import { Vehicle, TransactionType } from '../types';
import { addFuelLog } from '../services/googleSheetService';
import Spinner from './common/Spinner';

interface FuelLogFormProps {
  vehicles: Vehicle[];
  onFormSubmit: (notification: { show: boolean; message: string; isError: boolean }) => void;
}

const FuelLogForm: React.FC<FuelLogFormProps> = ({ vehicles, onFormSubmit }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    transactionType: TransactionType.In,
    fuelType: 'ดีเซล',
    volume: 0,
    vehicleReg: '',
    operator: '',
    vehicleType: '',
    mileage: 0,
    notes: '',
  });

  const handleVehicleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedVehicle = vehicles.find(v => v.vehicleNo === e.target.value);
    setFormData(prev => ({
        ...prev,
        vehicleReg: selectedVehicle?.vehicleNo || '',
        vehicleType: selectedVehicle?.vehicleType || '',
    }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const isNumber = type === 'number';
    setFormData(prev => ({ ...prev, [name]: isNumber ? parseFloat(value) : value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
     if (!formData.operator || !formData.fuelType || formData.volume <= 0) {
        onFormSubmit({ show: true, message: 'กรุณากรอกข้อมูลที่จำเป็น', isError: true });
        return;
    }
    if (formData.transactionType === TransactionType.Out && !formData.vehicleReg) {
        onFormSubmit({ show: true, message: 'กรุณาเลือกรถเมื่อเบิกออก', isError: true });
        return;
    }

    setIsLoading(true);
    const now = new Date();
    const rowData = [
        new Date().toISOString(), // ID
        now.toLocaleDateString('th-TH'),
        now.toLocaleTimeString('th-TH'),
        formData.transactionType,
        formData.fuelType,
        formData.volume,
        formData.vehicleReg,
        formData.operator,
        formData.vehicleType,
        formData.mileage,
        formData.notes
    ];
    
    try {
      await addFuelLog(rowData);
      onFormSubmit({ show: true, message: 'บันทึกข้อมูลน้ำมันสำเร็จ', isError: false });
      setFormData({
         transactionType: TransactionType.In, fuelType: 'ดีเซล', volume: 0, vehicleReg: '', operator: '', vehicleType: '', mileage: 0, notes: '',
      });
    } catch (error) {
      onFormSubmit({ show: true, message: 'เกิดข้อผิดพลาดในการบันทึก', isError: true });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-xl shadow-lg max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">บันทึกรับ-จ่ายน้ำมันเชื้อเพลิง</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
            <label className="block text-sm font-medium text-gray-700">ประเภทรายการ</label>
            <div className="mt-2 flex space-x-4">
                <button type="button" onClick={() => setFormData(p => ({...p, transactionType: TransactionType.In, vehicleReg: ''}))} className={`px-4 py-2 rounded-md w-full ${formData.transactionType === TransactionType.In ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>รับเข้า</button>
                <button type="button" onClick={() => setFormData(p => ({...p, transactionType: TransactionType.Out}))} className={`px-4 py-2 rounded-md w-full ${formData.transactionType === TransactionType.Out ? 'bg-orange-600 text-white' : 'bg-gray-200'}`}>เบิกออก</button>
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div>
                <label htmlFor="fuelType" className="block text-sm font-medium text-gray-700">ประเภทน้ำมัน</label>
                <select id="fuelType" name="fuelType" value={formData.fuelType} onChange={handleChange} className="mt-1 block w-full p-2 border border-gray-300 rounded-md">
                    <option>ดีเซล</option>
                    <option>เบนซิน</option>
                </select>
            </div>
             <div>
                <label htmlFor="volume" className="block text-sm font-medium text-gray-700">ปริมาณ (ลิตร)</label>
                <input type="number" id="volume" name="volume" step="0.01" min="0" value={formData.volume} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/>
            </div>
            <div>
              <label htmlFor="vehicleReg" className="block text-sm font-medium text-gray-700">ทะเบียนรถ (ถ้ามี)</label>
              <select id="vehicleReg" name="vehicleReg" value={formData.vehicleReg} onChange={handleVehicleChange} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" disabled={formData.transactionType === TransactionType.In}>
                <option value="">-- เลือกรถ --</option>
                {vehicles.map(v => <option key={v.id} value={v.vehicleNo}>{v.vehicleNo}</option>)}
              </select>
            </div>
            <div>
                <label htmlFor="mileage" className="block text-sm font-medium text-gray-700">เลขไมล์ (ถ้ามี)</label>
                <input type="number" id="mileage" name="mileage" min="0" value={formData.mileage} onChange={handleChange} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" disabled={formData.transactionType === TransactionType.In}/>
            </div>
            <div>
                <label htmlFor="operator" className="block text-sm font-medium text-gray-700">ผู้ทำรายการ</label>
                <input type="text" id="operator" name="operator" value={formData.operator} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/>
            </div>
        </div>
         <div>
            <label htmlFor="notes" className="block text-sm font-medium text-gray-700">หมายเหตุ</label>
            <textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} rows={3} className="mt-1 block w-full p-2 border border-gray-300 rounded-md"></textarea>
        </div>
        <div className="flex justify-end">
            <button type="submit" disabled={isLoading} className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-300 flex items-center">
                {isLoading && <Spinner />}
                {isLoading ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}
            </button>
        </div>
      </form>
    </div>
  );
};

export default FuelLogForm;
