
import React, { useState } from 'react';
import { Vehicle, RepairRequestFormData } from '../types';
import { addRepairRequest } from '../services/googleSheetService';
import ImageUpload from './common/ImageUpload';
import Spinner from './common/Spinner';

interface RepairRequestFormProps {
  vehicles: Vehicle[];
  onFormSubmit: (notification: { show: boolean; message: string; isError: boolean }) => void;
  onCancel: () => void;
}

const RepairRequestForm: React.FC<RepairRequestFormProps> = ({ vehicles, onFormSubmit, onCancel }) => {
  const [formData, setFormData] = useState<RepairRequestFormData>({
    vehicleReg: '',
    problemDetails: '',
    requester: '',
    images: Array(4).fill(null),
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFilesChange = (files: (File | null)[]) => {
      setFormData(prev => ({ ...prev, images: files }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.vehicleReg || !formData.problemDetails || !formData.requester) {
      onFormSubmit({ show: true, message: 'กรุณากรอกข้อมูลให้ครบถ้วน', isError: true });
      return;
    }
    setIsLoading(true);
    try {
      await addRepairRequest(formData, formData.requester);
      onFormSubmit({ show: true, message: 'แจ้งซ่อมสำเร็จ', isError: false });
    } catch (error) {
      console.error(error);
      onFormSubmit({ show: true, message: 'เกิดข้อผิดพลาดในการแจ้งซ่อม', isError: true });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-xl shadow-lg max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">ฟอร์มแจ้งซ่อมรถ</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="vehicleReg" className="block text-sm font-medium text-gray-700">ทะเบียนรถ</label>
            <select
              id="vehicleReg"
              name="vehicleReg"
              value={formData.vehicleReg}
              onChange={handleChange}
              className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">เลือกทะเบียนรถ</option>
              {vehicles.map(v => (
                <option key={v.id} value={v.vehicleNo}>{v.vehicleNo} - {v.vehicleType}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="requester" className="block text-sm font-medium text-gray-700">ผู้แจ้งซ่อม</label>
            <input
              type="text"
              id="requester"
              name="requester"
              value={formData.requester}
              onChange={handleChange}
              className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
        </div>
        <div>
          <label htmlFor="problemDetails" className="block text-sm font-medium text-gray-700">รายละเอียดปัญหา</label>
          <textarea
            id="problemDetails"
            name="problemDetails"
            rows={4}
            value={formData.problemDetails}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            required
          ></textarea>
        </div>
        
        <ImageUpload onFilesChange={handleFilesChange} maxFiles={4} />

        <div className="flex items-center justify-end space-x-4 pt-4">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none"
          >
            ยกเลิก
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 flex items-center"
          >
            {isLoading && <Spinner />}
            {isLoading ? 'กำลังบันทึก...' : 'บันทึกแจ้งซ่อม'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default RepairRequestForm;
