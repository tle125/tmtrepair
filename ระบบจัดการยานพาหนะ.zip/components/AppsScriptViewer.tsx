
import React from 'react';

const appsScriptCode = `
const SHEET_ID = "1NmZ6JItgmf-xYhqos1kFrFU-82oRCU0FdsDOtTjR6q0";
const FOLDER_ID = "1AmhAhcBQoBYCAZ9XzfE3ONaih0MDIR0F";

// Main entry point for POST requests
function doPost(e) {
  try {
    const requestBody = JSON.parse(e.postData.contents);
    const action = requestBody.action;
    let responseData;

    switch (action) {
      case 'getData':
        responseData = getData(requestBody.sheetName);
        break;
      case 'appendRow':
        responseData = appendRow(requestBody.sheetName, requestBody.rowData);
        break;
      case 'updateRow':
        responseData = updateRow(requestBody.sheetName, requestBody.id, requestBody.updates);
        break;
      case 'uploadFile':
        responseData = uploadFile(requestBody.fileName, requestBody.mimeType, requestBody.data);
        break;
      default:
        throw new Error("Invalid action provided.");
    }

    return createJsonResponse({ status: 'success', data: responseData });
  } catch (error) {
    Logger.log(error.toString());
    return createJsonResponse({ status: 'error', message: error.toString() });
  }
}

// Helper to create a standard JSON response
function createJsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// Converts a sheet to a JSON array of objects
function sheetToJSON(sheet) {
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).getValues();
  
  // Create camelCase keys from headers
  const keys = headers.map(h => {
    // A simple mapping for the requested columns
    const mapping = {
      'เบอร์รถ': 'vehicleNo', 'ประเภทรถ': 'vehicleType', 'ประเภทยาง': 'tireType', 'ประเภทล้อ': 'wheelType',
      'รายการยาง': 'tireSpec', 'ยี่ห้อยาง': 'tireBrand', 'ID': 'id', 'วันที่แจ้ง': 'requestDate', 'ทะเบียนรถ': 'vehicleReg',
      'รายละเอียดปัญหา': 'problemDetails', 'ผู้แจ้งซ่อม': 'requester', 'สถานะ': 'status', 'ประเมินค่าใช้จ่าย': 'estimatedCost',
      'รูปภาพ 1': 'imageUrl1', 'รูปภาพ 2': 'imageUrl2', 'รูปภาพ 3': 'imageUrl3', 'รูปภาพ 4': 'imageUrl4',
      'ประวัติการสื่อสาร': 'communicationLog'
      // Add other mappings as needed
    };
    return mapping[h] || h.toString().toLowerCase().replace(/\\s+/g, '_');
  });

  return data.map(row => {
    const obj = {};
    keys.forEach((key, i) => {
      obj[key] = row[i];
    });
    return obj;
  });
}

// Fetches all data from a specified sheet
function getData(sheetName) {
  if (!sheetName) throw new Error("Sheet name is required.");
  const spreadsheet = SpreadsheetApp.openById(SHEET_ID);
  const sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) throw new Error(\`Sheet "\${sheetName}" not found.\`);
  return sheetToJSON(sheet);
}

// Appends a new row to a specified sheet
function appendRow(sheetName, rowData) {
  if (!sheetName || !rowData) throw new Error("Sheet name and row data are required.");
  const spreadsheet = SpreadsheetApp.openById(SHEET_ID);
  const sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) throw new Error(\`Sheet "\${sheetName}" not found.\`);

  // Generate ID if the first column is for ID
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  if (headers[0] && headers[0].toUpperCase() === 'ID') {
      rowData.unshift(\`ID-\${new Date().getTime()}-\${Math.random().toString(36).substr(2, 9)}\`);
  }
  
  sheet.appendRow(rowData);
  return { status: 'success', message: 'Row added.' };
}

// Updates a specific row identified by ID
function updateRow(sheetName, id, updates) {
  if (!sheetName || !id || !updates) throw new Error("Sheet name, ID, and updates are required.");
  const spreadsheet = SpreadsheetApp.openById(SHEET_ID);
  const sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) throw new Error(\`Sheet "\${sheetName}" not found.\`);

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const idColIndex = headers.findIndex(h => h.toUpperCase() === 'ID') + 1;
  if (idColIndex === 0) throw new Error("ID column not found.");
  
  const data = sheet.getRange(2, idColIndex, sheet.getLastRow() - 1, 1).getValues();
  const rowNum = data.findIndex(row => row[0] == id) + 2;
  
  if (rowNum < 2) throw new Error(\`Row with ID \${id} not found.\`);

  Object.keys(updates).forEach(key => {
    // Mapping from frontend key to Thai header
    const headerMapping = {
        status: 'สถานะ',
        communicationLog: 'ประวัติการสื่อสาร'
        // Add other mappings
    };
    const headerName = headerMapping[key] || key;
    const colIndex = headers.indexOf(headerName) + 1;
    if (colIndex > 0) {
      sheet.getRange(rowNum, colIndex).setValue(updates[key]);
    }
  });

  return { status: 'success', message: \`Row \${id} updated.\` };
}

// Uploads a file to Google Drive from a base64 string
function uploadFile(fileName, mimeType, data) {
  if (!fileName || !mimeType || !data) throw new Error("File name, mime type, and data are required.");
  
  const folder = DriveApp.getFolderById(FOLDER_ID);
  const decodedData = Utilities.base64Decode(data);
  const blob = Utilities.newBlob(decodedData, mimeType, fileName);
  const file = folder.createFile(blob);
  
  // Set file to be publicly viewable
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  
  return file.getId();
}
`;

const AppsScriptViewer: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Apps Script Code (Code.gs)</h2>
      <p className="text-sm text-gray-600 mb-4">
        นี่คือโค้ดฝั่ง Backend ที่ทำงานบน Google Apps Script เพื่อเชื่อมต่อกับ Google Sheets และ Google Drive
      </p>
      <div className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
        <pre>
          <code className="language-javascript font-mono text-sm">
            {appsScriptCode.trim()}
          </code>
        </pre>
      </div>
    </div>
  );
};

export default AppsScriptViewer;
