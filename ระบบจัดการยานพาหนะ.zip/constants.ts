
export const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbynhKh0wHmaAETrjtcTeP4NFotBBnZgHWp8UTyPIUOB4csCX-mTIiajlivLmoObDxeh/exec";

export const SHEET_IDS = {
    vehicles: "ข้อมูลรถ",
    repairs: "บันทึกแจ้งซ่อม",
    tires: "บันทึกรับจ่ายยาง",
    fuel: "บันทึกรับจ่ายน้ำมันเชื้อเพลิง",
};
