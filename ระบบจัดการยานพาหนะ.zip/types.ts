
export interface Vehicle {
  id: string;
  vehicleNo: string;
  vehicleType: string;
  tireType: string;
  wheelType: string;
  tireSpec: string;
  tireBrand: string;
}

export enum RepairStatus {
  Pending = "รอดำเนินการซ่อม",
  InProgress = "กำลังซ่อม",
  Repaired = "ซ่อมเสร็จแล้ว",
  Closed = "ปิดงานแล้ว",
  Cancelled = "ยกเลิกงานซ่อม",
  InfoRequested = "ตอบกลับขอข้อมูล",
}

export interface Communication {
  timestamp: string;
  author: string;
  message: string;
}

export interface RepairRequest {
  id: string;
  requestDate: string;
  vehicleReg: string;
  problemDetails: string;
  requester: string;
  status: RepairStatus;
  estimatedCost: string;
  imageUrl1: string;
  imageUrl2: string;
  imageUrl3: string;
  imageUrl4: string;
  communicationLog: string; // JSON string of Communication[]
}

export interface RepairRequestFormData {
  vehicleReg: string;
  problemDetails: string;
  requester: string;
  images: (File | null)[];
}

export enum TransactionType {
  In = "รับเข้า",
  Out = "เบิกออก",
}

export interface TireLog {
  id: string;
  date: string;
  time: string;
  transactionType: TransactionType;
  tireCode: string;
  tireSize: string;
  brand: string;
  quantity: number;
  operator: string;
  vehicleType: string;
  vehicleReg: string;
  notes: string;
}

export interface FuelLog {
  id: string;
  date: string;
  time: string;
  transactionType: TransactionType;
  fuelType: string;
  volume: number;
  vehicleReg?: string;
  operator: string;
  vehicleType: string;
  mileage: number;
  notes: string;
}

export type Page = 'repairs' | 'tire' | 'fuel' | 'vehicles' | 'new_repair' | 'apps_script';

export interface NotificationState {
  show: boolean;
  message: string;
  isError: boolean;
}
