import React, { useState, useEffect, useCallback } from 'react';
import { Page, Vehicle, NotificationState } from './types';
import { getData } from './services/googleSheetService';
import { SHEET_IDS } from './constants';
import RepairRequestList from './components/RepairRequestList';
import RepairRequestForm from './components/RepairRequestForm';
import TireLogForm from './components/TireLogForm';
import FuelLogForm from './components/FuelLogForm';
import VehicleInfoList from './components/VehicleInfoList';
import AppsScriptViewer from './components/AppsScriptViewer';
import Notification from './components/common/Notification';
import Spinner from './components/common/Spinner';

// Sidebar Navigation Item Component
const NavItem: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center w-full px-4 py-3 text-left text-sm font-medium rounded-lg transition-colors duration-150 ${
      isActive
        ? 'bg-blue-600 text-white'
        : 'text-gray-600 hover:bg-gray-200 hover:text-gray-800'
    }`}
  >
    {icon}
    <span className="ml-3">{label}</span>
  </button>
);

const App: React.FC = () => {
  const [page, setPage] = useState<Page>('repairs');
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [isLoadingVehicles, setIsLoadingVehicles] = useState(true);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [notification, setNotification] = useState<NotificationState>({
    show: false,
    message: '',
    isError: false,
  });

  const handleNotificationChange = (newState: NotificationState) => {
    setNotification(newState);
    if (newState.show) {
      setTimeout(() => {
        setNotification({ show: false, message: '', isError: false });
      }, 4000);
    }
  };

  const fetchVehicleData = useCallback(async () => {
    setIsLoadingVehicles(true);
    try {
      const data = await getData<Vehicle>(SHEET_IDS.vehicles);
      setVehicles(data);
    } catch (error) {
      handleNotificationChange({ show: true, message: 'ไม่สามารถโหลดข้อมูลรถได้', isError: true });
    } finally {
      setIsLoadingVehicles(false);
    }
  }, []);

  useEffect(() => {
    fetchVehicleData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  
  const handlePageChange = (newPage: Page) => {
    setPage(newPage);
    setSidebarOpen(false); // Close sidebar on page change
  };

  const renderPage = () => {
    switch (page) {
      case 'repairs':
        return <RepairRequestList onNotification={handleNotificationChange} />;
      case 'new_repair':
        return <RepairRequestForm vehicles={vehicles} onFormSubmit={(notif) => {
          handleNotificationChange(notif);
          if(!notif.isError) {
            setPage('repairs');
          }
        }} onCancel={() => setPage('repairs')} />;
      case 'tire':
        return <TireLogForm vehicles={vehicles} onFormSubmit={handleNotificationChange} />;
      case 'fuel':
        return <FuelLogForm vehicles={vehicles} onFormSubmit={handleNotificationChange} />;
      case 'vehicles':
        return <VehicleInfoList vehicles={vehicles} isLoading={isLoadingVehicles} />;
      case 'apps_script':
        return <AppsScriptViewer />;
      default:
        return <RepairRequestList onNotification={handleNotificationChange} />;
    }
  };

  const navItems = [
    { id: 'repairs', label: 'รายการแจ้งซ่อม', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg> },
    { id: 'tire', label: 'จัดการยางรถ', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M10.5 21a9 9 0 1 1 3-17.5M10.5 21V3m0 18a9 9 0 0 0 3-17.5M10.5 3a9 9 0 0 0-3 17.5m3-17.5a9 9 0 0 1 6 15" /></svg> },
    { id: 'fuel', label: 'จัดการน้ำมัน', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M12 6V3m0 18v-3m0-12a9 9 0 110 12 9 9 0 010-12z" /></svg> },
    { id: 'vehicles', label: 'ข้อมูลรถ', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg> },
    { id: 'apps_script', label: 'Apps Script Code', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg> },
  ];
  
  const SidebarContent = () => (
    <div className="py-4 text-gray-500">
      <a className="ml-6 text-lg font-bold text-gray-800" href="#">ระบบจัดการยานพาหนะ</a>
      <div className="mt-8 space-y-2 px-2">
        {navItems.map(item => (
          <NavItem key={item.id} label={item.label} icon={item.icon} isActive={page === item.id} onClick={() => handlePageChange(item.id as Page)} />
        ))}
      </div>
      <div className="px-6 my-6">
          <button
              onClick={() => handlePageChange('new_repair')}
              className="flex items-center justify-center w-full px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-blue-600 border border-transparent rounded-lg active:bg-blue-600 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue"
          >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
              แจ้งซ่อมใหม่
          </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Desktop Sidebar */}
      <aside className="z-20 hidden w-64 overflow-y-auto bg-white md:block flex-shrink-0">
          <SidebarContent />
      </aside>
      {/* Mobile Sidebar */}
      <div className={`fixed inset-0 z-30 flex items-end bg-black bg-opacity-50 sm:items-center sm:justify-center md:hidden ${isSidebarOpen ? '' : 'hidden'}`} onClick={() => setSidebarOpen(false)}>
      </div>
      <aside className={`fixed inset-y-0 z-40 flex-shrink-0 w-64 mt-0 overflow-y-auto bg-white md:hidden transform transition-transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <SidebarContent />
      </aside>

      <div className="flex flex-col flex-1 w-full">
        <header className="z-10 py-4 bg-white shadow-md md:hidden">
          <div className="container mx-auto px-6 flex items-center justify-between h-full">
             <button
              className="p-1 mr-5 -ml-1 rounded-md md:hidden focus:outline-none focus:shadow-outline-purple"
              onClick={() => setSidebarOpen(true)}
              aria-label="Menu"
            >
              <svg className="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd"></path>
              </svg>
            </button>
            <h1 className="text-lg font-bold text-gray-800">ระบบจัดการยานพาหนะ</h1>
            <div></div>
          </div>
        </header>

        <main className="h-full overflow-y-auto">
          <div className="container px-6 py-8 mx-auto">
            {isLoadingVehicles ? <Spinner /> : renderPage()}
          </div>
        </main>
      </div>

      {notification.show && (
        <Notification
          message={notification.message}
          isError={notification.isError}
          onClose={() => setNotification(prev => ({ ...prev, show: false }))}
        />
      )}
    </div>
  );
};

export default App;